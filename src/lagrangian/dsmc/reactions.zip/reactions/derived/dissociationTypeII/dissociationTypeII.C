/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2007 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description

\*---------------------------------------------------------------------------*/

#include "dissociationTypeII.H"
#include "addToRunTimeSelectionTable.H"
#include "fvc.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{

defineTypeNameAndDebug(dissociationTypeII, 0);

addToRunTimeSelectionTable(dsmcReaction, dissociationTypeII, dictionary);



// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
dissociationTypeII::dissociationTypeII
(
    Time& t,
    dsmcCloud& cloud,
    const dictionary& dict
)
:
    dsmcReaction(t, cloud, dict),
    propsDict_(dict.subDict(typeName + "Properties")),
    reactantIds_(),
    productIds_(),
    reactionName_(propsDict_.lookup("reactionName")),
    heatOfReaction_(readScalar(propsDict_.lookup("heatOfReaction"))),
    relax_(true),
    allowSplitting_(false),
    writeRatesToTerminal_(false),
    volume_(0.0),
    numberDensities_(2, 0.0)
{

}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

dissociationTypeII::~dissociationTypeII()
{}

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void dissociationTypeII::initialConfiguration()
{
    setProperties();
}

void dissociationTypeII::setProperties()
{
    // reading in reactants

    const List<word> reactantMolecules (propsDict_.lookup("reactantMoleculesToDissociate"));

    if(reactantMolecules.size() != 2)
    {
        FatalErrorIn("dissociationTypeII::setProperties()")
            << "There should be two or more reactants, instead of " 
            << reactantMolecules.size() << nl 
            << exit(FatalError);
    }
    
    if(reactantMolecules[0] == reactantMolecules[1])
    {
        FatalErrorIn("dissociationTypeII::setProperties()")
            << "Reactant molecules cannot be same species." << nl
            << exit(FatalError);
    }

    reactantIds_.setSize(reactantMolecules.size(), -1);

    allowSplitting_ = Switch(propsDict_.lookup("allowSplitting"));
    
    writeRatesToTerminal_ = Switch(propsDict_.lookup("writeRatesToTerminal"));

    forAll(reactantIds_, r)
    {
        reactantIds_[r] = findIndex(cloud_.typeIdList(), reactantMolecules[r]);

        // check that reactants belong to the typeIdList (constant/dsmcProperties)
        if(reactantIds_[r] == -1)
        {
            FatalErrorIn("dissociationTypeII::setProperties()")
                << "Cannot find type id: " << reactantMolecules[r] << nl 
                << exit(FatalError);
        }
    }
    
    // check that reactant one is a 'MOLECULE' (not an 'ATOM') 

    const scalar& rDof1 = cloud_.constProps(reactantIds_[0]).rotationalDegreesOfFreedom();

    if(rDof1 < 1)
    {
        FatalErrorIn("dissociationTypeII::setProperties()")
            << "First reactant must be a molecule (not an atom): " << reactantMolecules[0] 
            << nl 
            << exit(FatalError);
    }
    
    // check that reactant two is a 'MOLECULE' (not an 'ATOM') 

    const scalar& rDof2 = cloud_.constProps(reactantIds_[1]).rotationalDegreesOfFreedom();

    if(rDof2 != 0)
    {
        FatalErrorIn("dissociationTypeII::setProperties()")
            << "Second reactant must be an atom (not a molecule): " << reactantMolecules[1] 
            << nl 
            << exit(FatalError);
    }

    // reading in products

    List<word> productMolecules (propsDict_.lookup("productsOfDissociatedMolecule"));

    if(productMolecules.size() != 2)
    {
        FatalErrorIn("dissociationTypeII::setProperties()")
            << "Number of products is " << productMolecules.size() <<
            ", should be two."
            << exit(FatalError);
    }
    

    productIds_.setSize(productMolecules.size());

    forAll(productMolecules, r)
    {
        if(productIds_.size() != 2)
        {
            FatalErrorIn("dissociationTypeII::setProperties()")
                << "There should be two products (for the dissociating molecule "
                << reactantMolecules[r] << "), instead of " 
                << productIds_.size() << nl 
                << exit(FatalError);
        }
    
        forAll(productIds_, r)
        {
            productIds_[r] = findIndex(cloud_.typeIdList(), productMolecules[r]);

            // check that reactants belong to the typeIdList (constant/dsmcProperties)
            if(productIds_[r] == -1)
            {
                FatalErrorIn("dissociationTypeII::setProperties()")
                    << "Cannot find type id: " << productMolecules[r] << nl 
                    << exit(FatalError);
            }
        }
        
        // check that product one is an 'ATOM' (not a 'MOLECULE') 

        const scalar& rDof3 = cloud_.constProps(productIds_[0]).rotationalDegreesOfFreedom();

        if(rDof3 != 0)
        {
            FatalErrorIn("dissociationTypeII::setProperties()")
                << "First product must be an atom (not a molecule): " << productMolecules[0] 
                << nl 
                << exit(FatalError);
        }

        // check that product two is an 'ATOM' (not a 'MOLECULE') 

        const scalar& rDof4 = cloud_.constProps(productIds_[1]).rotationalDegreesOfFreedom();

        if(rDof4 != 0)
        {
            FatalErrorIn("dissociationTypeII::setProperties()")
                << "Second product must be an atom (not a molecule): " << productMolecules[1] 
                << nl 
                << exit(FatalError);
        }
    }
}

bool dissociationTypeII::tryReactMolecules(const label& typeIdP, const label& typeIdQ)
{
    label reactantPId = findIndex(reactantIds_, typeIdP);
    label reactantQId = findIndex(reactantIds_, typeIdQ);

    if(reactantPId != reactantQId)
    {
        if
        (
            (reactantPId != -1) &&
            (reactantQId != -1) 
        )
        {
            return true;
        }
    }

    if
    (
        (reactantPId != -1) &&
        (reactantQId != -1) &&
        (reactantPId != reactantQId)
    )
    {
        return true;
    }
    else
    {
        return false;
    }
}

void dissociationTypeII::reaction
(
    dsmcParcel& p,
    dsmcParcel& q,
    const DynamicList<label>& candidateList,
    const List<DynamicList<label> >& candidateSubList,
    const label& candidateP,
    const List<label>& whichSubCell
)
{
}


void dissociationTypeII::reaction
(
    dsmcParcel& p,
    dsmcParcel& q
)
{
    label typeIdP = p.typeId();
    label typeIdQ = q.typeId();

    if(typeIdP == reactantIds_[0] && typeIdQ == reactantIds_[1]) // This produces the correct equilibrium rate A2 + X.
    {
        vector UP = p.U();
        vector UQ = q.U();
        scalar ERotP = p.ERot();
        scalar EVibP = p.EVib();

        scalar mP = cloud_.constProps(typeIdP).mass();
        scalar mQ = cloud_.constProps(typeIdQ).mass();

        scalar mR = mP*mQ/(mP + mQ);
        scalar cRsqr = magSqr(UP - UQ);
        scalar translationalEnergy = 0.5*mR*cRsqr;
        
        scalar rotationalDofP = cloud_.constProps(typeIdP).rotationalDegreesOfFreedom();    
        scalar thetaVP = cloud_.constProps(typeIdP).thetaV();

        scalar heatOfReactionJoules = heatOfReaction_*physicoChemical::k.value();

        scalar omegaPQ =
        0.5
        *(
            cloud_.constProps(typeIdP).omega()
            + cloud_.constProps(typeIdQ).omega()
        );
        
        scalar ChiB = 2.5 - omegaPQ;

        scalar EcPP = 0.0;
        label idP = cloud_.constProps(typeIdP).charDissQuantumLevel();
        label imaxP = 0;
        
        // calculate if a dissociation of species P is possible
        EcPP = translationalEnergy + EVibP;

        imaxP = EcPP/(physicoChemical::k.value()*thetaVP);

        if(imaxP-idP > 0)
        {
            nReactionsPerTimeStep_++;
            nTotReactions_++;

            relax_ = false;

            if(allowSplitting_)
            {
                relax_ = false;
                
//                 scalar Ecoll = translationalEnergy + ERotP + EVibP + heatOfReactionJoules;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////////
//                 
//                 scalar Erel = Ecoll*cloud_.PSIm( (5.0 - 2.0*omegaPQ), 2.0*(5.0 - 2.0*omegaPQ) );
//                 
//                 scalar Erot = Ecoll - Erel;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////////
//                 
//                 scalar Ecplx = Erot;
//                 scalar Erot2 = 0.0;
//                 scalar Evib2 = 0.0;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////////
//  
// 
//                 scalar relVelNonDissoMol = sqrt(2.0*Erel/mR);
                
                translationalEnergy = translationalEnergy + heatOfReactionJoules + EVibP;
                
                //Particle P is dissociating, so no vibrational redistribution to it
                
                //Particle Q is an atom, so no redistribution required for it
                
                if (0.2 > cloud_.rndGen().scalar01())
                {
                    scalar EcP = translationalEnergy + ERotP;
                    
                    scalar energyRatio = 0.0;
                    
                    if(rotationalDofP == 2.0)
                    {
                        energyRatio = 1.0 - pow(cloud_.rndGen().scalar01(),(1.0/ChiB));
                    }
                    else
                    {
                        scalar ChiA = 0.5*rotationalDofP;
                        
                        energyRatio = cloud_.energyRatio(ChiA, ChiB);
                    }

                    ERotP = energyRatio*EcP;
                
                    translationalEnergy = EcP - ERotP;
                }
                
                scalar relVelNonDissoMol = sqrt(2.0*translationalEnergy/mR);

                //center of mass velocity of all particles
                vector Ucm = (mP*UP + mQ*UQ)/(mP + mQ);

                // Variable Hard Sphere collision part
    
                scalar cosTheta = 2.0*cloud_.rndGen().scalar01() - 1.0;
            
                scalar sinTheta = sqrt(1.0 - cosTheta*cosTheta);
            
                scalar phi = twoPi*cloud_.rndGen().scalar01();
            
                vector postCollisionRelU =
                    relVelNonDissoMol
                    *vector
                        (
                            cosTheta,
                            sinTheta*cos(phi),
                            sinTheta*sin(phi)
                        );
    
                UP = Ucm + postCollisionRelU*mQ/(mP + mQ);
                UQ = Ucm - postCollisionRelU*mP/(mP + mQ); // Q is the NON-DISSOCIATING molecule.

                label p1 = 0;
                label p2 = 1;

                const label& typeId1 = productIds_[p1];
                const label& typeId2 = productIds_[p2];

                //Mass of Product one and two
                scalar mP1 = cloud_.constProps(typeId1).mass();
                scalar mP2 = cloud_.constProps(typeId2).mass();

                scalar mRatoms = mP1*mP2/(mP1 + mP2);

                //center of mass velocity of all particles

                vector UcmAtoms = UP;

//                 scalar cRatoms = sqrt(2.0*Ecplx/mRatoms);
                
                scalar cRatoms = sqrt(2.0*ERotP/mRatoms);

                // Variable Hard Sphere collision part
            
                scalar cosTheta2 = 2.0*cloud_.rndGen().scalar01() - 1.0;
            
                scalar sinTheta2 = sqrt(1.0 - cosTheta2*cosTheta2);
            
                scalar phi2 = twoPi*cloud_.rndGen().scalar01();
            
                vector postCollisionRelU2 = cRatoms
                *vector
                    (
                        cosTheta2,
                        sinTheta2*cos(phi2),
                        sinTheta2*sin(phi2)
                    );

                vector uP1 = UcmAtoms + postCollisionRelU2*mP2/(mP1 + mP2);
                vector uP2 = UcmAtoms - postCollisionRelU2*mP1/(mP1 + mP2);

                // New atom Q velocity.
                q.U() = UQ;

                // Molecule P will dissociate into 2 atoms.
                label cellI = p.cell();
                vector position = p.position();
                label tetFaceI = p.tetFace();
                label tetPtI = p.tetPt();
                
                p.typeId() = typeId1;
                p.U() = uP1;
                p.EVib() = 0.0;
                p.ERot() = 0.0;
                
                label classificationP = p.classification();
                
                // insert new product 2
                cloud_.addNewParcel
                (
                    position,
                    uP2,
                    0.0,
                    0.0,
                    cellI,
                    tetFaceI,
                    tetPtI,
                    typeId2,
                    0,
                    classificationP
                );
            }
        }
        else
        {
            relax_ = true;
        }
    }
  
    if(typeIdP == reactantIds_[1] && typeIdQ == reactantIds_[0]) // This produces the correct equilibrium rate X + A2.
    {
        vector UP = p.U();
        vector UQ = q.U();
        scalar ERotQ = q.ERot();
        scalar EVibQ = q.EVib();

        scalar mP = cloud_.constProps(typeIdP).mass();
        scalar mQ = cloud_.constProps(typeIdQ).mass();

        scalar mR = mP*mQ/(mP + mQ);
        scalar cRsqr = magSqr(UP - UQ);
        scalar translationalEnergy = 0.5*mR*cRsqr;
        
        scalar rotationalDofQ = cloud_.constProps(typeIdQ).rotationalDegreesOfFreedom();
        scalar heatOfReactionJoules = heatOfReaction_*physicoChemical::k.value();

        scalar omegaPQ =
        0.5
        *(
            cloud_.constProps(typeIdP).omega()
            + cloud_.constProps(typeIdQ).omega()
        );
        
        scalar ChiB = 2.5 - omegaPQ;
        
        scalar thetaVQ = cloud_.constProps(typeIdQ).thetaV();

        scalar EcPQ = 0.0;
        label idQ = cloud_.constProps(typeIdQ).charDissQuantumLevel();
        label imaxQ = 0;

        // calculate if a dissociation of species Q is possible
        EcPQ = translationalEnergy + EVibQ;

        imaxQ = EcPQ/(physicoChemical::k.value()*thetaVQ);	    

        if(imaxQ-idQ > 0)
        {
            nReactionsPerTimeStep_++;
            nTotReactions_++;
            
            if(allowSplitting_)
            {
                relax_ = false;
                
//                 scalar Ecoll = translationalEnergy + ERotQ + EVibQ + heatOfReactionJoules;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////////
//                 
//                 scalar Erel = Ecoll*cloud_.PSIm( (5.0 - 2.0*omegaPQ), 2.0*(5.0 - 2.0*omegaPQ) );
//                 
//                 scalar Erot = Ecoll - Erel;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////////
//                 
//                 scalar Ecplx = Erot;
//                 scalar Erot2 = 0.0;
//                 scalar Evib2 = 0.0;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////////
// 
//                 scalar relVelNonDissoMol = sqrt(2.0*Erel/mR);
                
                translationalEnergy = translationalEnergy + heatOfReactionJoules + EVibQ;
                
                //Particle Q is dissociating, so no vibrational redistribution to it
                
                //Particle P is an atom, so no redistribution required for it
                
                if (0.2 > cloud_.rndGen().scalar01())
                {
                    scalar EcQ = translationalEnergy + ERotQ;
                    
                    scalar energyRatio = 0.0;
                    
                    if(rotationalDofQ == 2.0)
                    {
                        energyRatio = 1.0 - pow(cloud_.rndGen().scalar01(),(1.0/ChiB));
                    }
                    else
                    {
                        scalar ChiA = 0.5*rotationalDofQ;
                        
                        energyRatio = cloud_.energyRatio(ChiA, ChiB);
                    }

                    ERotQ = energyRatio*EcQ;
                
                    translationalEnergy = EcQ - ERotQ;
                }
                
                scalar relVelNonDissoMol = sqrt(2.0*translationalEnergy/mR);

                //center of mass velocity of all particles
                vector Ucm = (mP*UP + mQ*UQ)/(mP + mQ);    

                // Variable Hard Sphere collision part
    
                scalar cosTheta = 2.0*cloud_.rndGen().scalar01() - 1.0;
            
                scalar sinTheta = sqrt(1.0 - cosTheta*cosTheta);
            
                scalar phi = twoPi*cloud_.rndGen().scalar01();
            
                vector postCollisionRelU =
                    relVelNonDissoMol
                    *vector
                        (
                            cosTheta,
                            sinTheta*cos(phi),
                            sinTheta*sin(phi)
                        );
    
                UP = Ucm + (postCollisionRelU*mQ/(mP + mQ)); // UP is the single atom
                UQ = Ucm - (postCollisionRelU*mP/(mP + mQ)); // UQ is used as Ucm for atomic split.
                
                label q1 = 0;
                label q2 = 1;

                const label& typeId1 = productIds_[q1];
                const label& typeId2 = productIds_[q2];
                
                //Mass of Product one and two
                scalar mP1 = cloud_.constProps(typeId1).mass();
                scalar mP2 = cloud_.constProps(typeId2).mass();
                
                scalar mRatoms = mP1*mP2/(mP1 + mP2);

//                 scalar cRatoms = sqrt(2.0*Ecplx/mRatoms);
                
                scalar cRatoms = sqrt(2.0*ERotQ/mRatoms);

                // Variable Hard Sphere collision part
                scalar cosTheta2 = 2.0*cloud_.rndGen().scalar01() - 1.0;
            
                scalar sinTheta2 = sqrt(1.0 - cosTheta2*cosTheta2);
            
                scalar phi2 = twoPi*cloud_.rndGen().scalar01();
            
                vector postCollisionRelU2 = cRatoms
                *vector
                    (
                        cosTheta2,
                        sinTheta2*cos(phi2),
                        sinTheta2*sin(phi2)
                    );


                vector uP1 = UQ + postCollisionRelU2*mP2/(mP1 + mP2);
                vector uP2 = UQ - postCollisionRelU2*mP1/(mP1 + mP2);

                // P remains NON-DISSOCIATED (it is an atom).
                p.U() = UP;

                // Molecule Q will dissociate into 2 atoms.
                label cellI = q.cell();
                vector position = q.position();
                label tetFaceI = q.tetFace();
                label tetPtI = q.tetPt();
                
                q.typeId() = typeId1;
                q.U() = uP1;
                q.EVib() = 0.0;
                q.ERot() = 0.0;
                
                label classificationQ = q.classification();
                
                // insert new product 2
                cloud_.addNewParcel
                (
                    position,
                    uP2,
                    0.0,
                    0.0,
                    cellI,
                    tetFaceI,
                    tetPtI,
                    typeId2,
                    0,
                    classificationQ
                );
            }
        }
        else
        {
            relax_ = true;
        }
    }
}

void  dissociationTypeII::outputResults(const label& counterIndex)
{    
    if(writeRatesToTerminal_ == true)
    {
        const List< DynamicList<dsmcParcel*> >& cellOccupancy
            = cloud_.cellOccupancy();

        List<label> mols (2, 0);
        volume_ = 0.0;

        forAll(cellOccupancy, c)
        {
            const List<dsmcParcel*>& parcelsInCell = cellOccupancy[c];

            forAll(parcelsInCell, pIC)
            {
                dsmcParcel* p = parcelsInCell[pIC];

                label id = findIndex(reactantIds_, p->typeId());

                if(id != -1)
                {
                    mols[id]++;
                }
            }

            volume_ += mesh_.cellVolumes()[c];
        }
        
        scalar volume = volume_;
        label nTotReactions = nTotReactions_;

        //- Parallel communication
        if(Pstream::parRun())
        {
            reduce(volume, sumOp<scalar>());
            reduce(mols[0], sumOp<label>());
            reduce(mols[1], sumOp<label>());
            reduce(nTotReactions, sumOp<label>());
        }

        numberDensities_[0] = (mols[0]*cloud().nParticle())/volume;
        numberDensities_[1] = (mols[1]*cloud().nParticle())/volume;

        const scalar& deltaT = mesh_.time().deltaT().value();

        word reactantMolA = cloud_.typeIdList()[reactantIds_[0]];
        word reactantMolB = cloud_.typeIdList()[reactantIds_[1]];

        word productMolA = cloud_.typeIdList()[productIds_[0]];
        word productMolB = cloud_.typeIdList()[productIds_[1]];

        if((numberDensities_[0] > 0.0) && (numberDensities_[1] > 0.0))
        { 

            scalar reactionRate = 0.0;

            reactionRate =
            (
            nTotReactions
            * cloud_.nParticle()
            )/(counterIndex*deltaT*numberDensities_[0]* numberDensities_[1]*volume);

            Info<< "Dissociation type II reaction "
                <<  reactantMolA << " + " << reactantMolB 
                <<  " --> "
                << productMolA << " + " << productMolB << " + " << reactantMolB 
                << ", reaction rate = " << reactionRate
                << endl;
        }
    }
    else
    {
        label nTotReactions = nTotReactions_;   
        
        if(Pstream::parRun())
        {
            reduce(nTotReactions, sumOp<label>());
        }
    
        if(nTotReactions > VSMALL)
        {
                word reactantMolA = cloud_.typeIdList()[reactantIds_[0]];
                word reactantMolB = cloud_.typeIdList()[reactantIds_[1]];

                word productMolA = cloud_.typeIdList()[productIds_[0]];
                word productMolB = cloud_.typeIdList()[productIds_[1]];
            
                Info<< "Dissociation type II reaction "
                <<  reactantMolA << " + " << reactantMolB 
                <<  " --> "
                << productMolA << " + " << productMolB << " + " << reactantMolB  
                    << " is active." << endl;
        }       
    }

    nReactionsPerTimeStep_ = 0.0;

}


const bool& dissociationTypeII::relax() const
{
    return relax_;
}

}
// End namespace Foam

// ************************************************************************* //
