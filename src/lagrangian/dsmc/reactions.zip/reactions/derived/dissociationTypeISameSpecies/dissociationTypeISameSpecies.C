/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2007 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description

\*---------------------------------------------------------------------------*/

#include "dissociationTypeISameSpecies.H"
#include "addToRunTimeSelectionTable.H"
#include "fvc.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{

defineTypeNameAndDebug(dissociationTypeISameSpecies, 0);

addToRunTimeSelectionTable(dsmcReaction, dissociationTypeISameSpecies, dictionary);



// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
dissociationTypeISameSpecies::dissociationTypeISameSpecies
(
    Time& t,
    dsmcCloud& cloud,
    const dictionary& dict
)
:
    dsmcReaction(t, cloud, dict),
    propsDict_(dict.subDict(typeName + "Properties")),
    reactantIds_(),
    productIds_(),
    reactionName_(propsDict_.lookup("reactionName")),
    heatOfReaction_(readScalar(propsDict_.lookup("heatOfReaction"))),
    relax_(true),
    allowSplitting_(false),
    writeRatesToTerminal_(false),
    volume_(0.0),
    numberDensities_(2, 0.0)
{

}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

dissociationTypeISameSpecies::~dissociationTypeISameSpecies()
{}

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void dissociationTypeISameSpecies::initialConfiguration()
{
    setProperties();
}

void dissociationTypeISameSpecies::setProperties()
{
    // reading in reactants

    const List<word> reactantMolecules (propsDict_.lookup("reactantMoleculesToDissociate"));

    if(reactantMolecules.size() != 2)
    {
        FatalErrorIn("dissociationTypeISameSpecies::setProperties()")
            << "There should be two reactants, instead of " 
            << reactantMolecules.size() << nl 
            << exit(FatalError);
    }
    
    if(reactantMolecules[0] != reactantMolecules[1])
    {
        FatalErrorIn("dissociationTypeISameSpecies::setProperties()")
            << "Both reactant species must be the same, they are currently " 
	    << reactantMolecules[0] << " and " << reactantMolecules[1] << nl 
            << exit(FatalError);
    }

    reactantIds_.setSize(reactantMolecules.size(), -1);

    allowSplitting_ = Switch(propsDict_.lookup("allowSplitting"));
    
    writeRatesToTerminal_ = Switch(propsDict_.lookup("writeRatesToTerminal"));

    forAll(reactantIds_, r)
    {
        reactantIds_[r] = findIndex(cloud_.typeIdList(), reactantMolecules[r]);

        // check that reactants belong to the typeIdList (constant/dsmcProperties)
        if(reactantIds_[r] == -1)
        {
            FatalErrorIn("dissociationTypeISameSpecies::setProperties()")
                << "Cannot find type id: " << reactantMolecules[r] << nl 
                << exit(FatalError);
        }

        // check that reactants are 'MOLECULES' (not 'ATOMS') 

        const scalar& rDof = cloud_.constProps(reactantIds_[r]).rotationalDegreesOfFreedom();
    
        if(rDof < 1)
        {
            FatalErrorIn("dissociationTypeISameSpecies::setProperties()")
                << "Reactant must be a molecule (not an atom): " << reactantMolecules[r] 
                << nl 
                << exit(FatalError);
        }
    }

    // reading in products

    const List<word> productMolecules (propsDict_.lookup("productsOfDissociatedMolecule"));

    if(productMolecules.size() != 2)
    {
        FatalErrorIn("dissociationTypeISameSpecies::setProperties()")
            << "There should be two products, instead of " 
            << productMolecules.size() << nl 
            << exit(FatalError);
    }
    
    productIds_.setSize(productMolecules.size(), -1);

    forAll(productIds_, r)
    {
        productIds_[r] = findIndex(cloud_.typeIdList(), productMolecules[r]);

        // check that products belong to the typeIdList (constant/dsmcProperties)
        if(productIds_[r] == -1)
        {
            FatalErrorIn("dissociationTypeISameSpecies::setProperties()")
                << "Cannot find type id: " << productMolecules[r] << nl 
                << exit(FatalError);
        }

        // check that products are 'ATOMS' (not 'MOLECULES') 

        const scalar& rDof = cloud_.constProps(productIds_[r]).rotationalDegreesOfFreedom();
    
        if(rDof > 1)
        {
            FatalErrorIn("dissociationTypeISameSpecies::setProperties()")
                << "Reactant must be an atom (not a molecule): " << productMolecules[r] 
                << nl 
                << exit(FatalError);
        }
    }
}

bool dissociationTypeISameSpecies::tryReactMolecules(const label& typeIdP, const label& typeIdQ)
{
    label reactantPId = findIndex(reactantIds_, typeIdP);
    label reactantQId = findIndex(reactantIds_, typeIdQ);

    if(reactantPId == reactantQId)
    {
        if
        (
            (reactantPId != -1) &&
            (reactantQId != -1) 
        )
        {
            return true;
        }
    }

    if
    (
        (reactantPId != -1) &&
        (reactantQId != -1) &&
        (reactantPId != reactantQId)
    )
    {
        return true;
    }
    else
    {
        return false;
    }

}

void dissociationTypeISameSpecies::reaction
(
    dsmcParcel& p,
    dsmcParcel& q,
    const DynamicList<label>& candidateList,
    const List<DynamicList<label> >& candidateSubList,
    const label& candidateP,
    const List<label>& whichSubCell
)
{
}


void dissociationTypeISameSpecies::reaction
(
    dsmcParcel& p,
    dsmcParcel& q
)
{
    label typeIdP = p.typeId();
    label typeIdQ = q.typeId();
    
    
    if(typeIdP == typeIdQ && typeIdP == reactantIds_[0]) // same species and desired species to measure rate for
    {
        vector UP = p.U();
        vector UQ = q.U();
        
        scalar ERotP = p.ERot();
        scalar ERotQ = q.ERot();
        scalar EVibP = p.EVib();
        scalar EVibQ = q.EVib();

        scalar mP = cloud_.constProps(typeIdP).mass();
        scalar mQ = cloud_.constProps(typeIdQ).mass();
        
        scalar thetaVQ = cloud_.constProps(typeIdQ).thetaV();
        scalar thetaDQ = cloud_.constProps(typeIdQ).thetaD();
        scalar ZrefQ = cloud_.constProps(typeIdQ).Zref();

        scalar refTempZvQ = cloud_.constProps(typeIdQ).TrefZv();
        
        scalar rotationalDofP = cloud_.constProps(typeIdP).rotationalDegreesOfFreedom();
        scalar rotationalDofQ = cloud_.constProps(typeIdQ).rotationalDegreesOfFreedom();

        scalar mR = mP*mQ/(mP + mQ);
        scalar cRsqr = magSqr(UP - UQ);
        scalar translationalEnergy = 0.5*mR*cRsqr;

        scalar heatOfReactionJoules = heatOfReaction_*physicoChemical::k.value();

        scalar omegaPQ =
            0.5
            *(
                    cloud_.constProps(typeIdP).omega()
                + cloud_.constProps(typeIdQ).omega()
            );
       
        scalar ChiB = 2.5 - omegaPQ;

        scalar EcPP = 0.0;
        label idP = cloud_.constProps(typeIdP).charDissQuantumLevel();
        label imaxP = 0;
        
        // calculate if a dissociation of species P is possible
        EcPP = translationalEnergy + EVibP;

        imaxP = EcPP/(physicoChemical::k.value()*cloud_.constProps(typeIdP).thetaV());

        if((imaxP-idP) > 0)
        {
            nReactionsPerTimeStep_++;
            nTotReactions_++;

            if(allowSplitting_)
            {
                
                relax_ = false;
                
                //Particle P is dissociating, so no vibrational redistribution to it
                
//                 scalar Ecoll = translationalEnergy + ERotP + EVibP + ERotQ + EVibQ + heatOfReactionJoules;
//                 
//                 ERotP = EVibP = ERotQ = EVibQ = 0.0;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////
// 
//                 scalar expo = 5.0 - 2.0*omegaPQ;
//                 
//                 scalar PSIvib= 0.0;
//                 scalar fnorm = 0.0;
//                 
//                 scalar rel =  Ecoll/(physicoChemical::k.value()*thetaVQ);
//                 
//                 do
//                 {
//                     PSIvib = (int)((((int)rel)+1)*cloud_.rndGen().scalar01())/rel;
//                     fnorm  = pow((1.0-PSIvib),expo);
//                 } while (fnorm < cloud_.rndGen().scalar01());
//                 
//                 scalar Evib2 = PSIvib*Ecoll;
//                 
//                 Ecoll -= Evib2;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////
//                     
//                 scalar Erel = Ecoll*cloud_.PSIm( (5.0 - 2.0*omegaPQ), 2.0*(5.0 - 2.0*omegaPQ)+rotationalDofQ );
//                 
//                 scalar Erot = Ecoll - Erel;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////
//                 
//                 scalar Ecplx = Erot*cloud_.PSIm( (5.0 - 2.0*omegaPQ),(5.0 - 2.0*omegaPQ)+rotationalDofQ );
//                 
//                 scalar Erot2 = Erot - Ecplx;
//                 
//                 ////////////////////////////////////////////////////////////////////////////////
// 
//                 scalar relVelNonDissoMol = sqrt((2.0*Erel)/mR);
                
                //Particle P is dissociating, so don't redistribute vibrational energy
                
                translationalEnergy = translationalEnergy + heatOfReactionJoules + EVibP;
                
                if (0.2 > cloud_.rndGen().scalar01())
                {
                    scalar EcP = translationalEnergy + ERotP;
                    
                    scalar energyRatio = 0.0;
                    
                    if(rotationalDofP == 2.0)
                    {
                        energyRatio = 1.0 - pow(cloud_.rndGen().scalar01(),(1.0/ChiB));
                    }
                    else
                    {
                        scalar ChiA = 0.5*rotationalDofP;
                        
                        energyRatio = cloud_.energyRatio(ChiA, ChiB);
                    }

                    ERotP = energyRatio*EcP;
                
                    translationalEnergy = EcP - ERotP;
                }
                
                scalar EcQ = translationalEnergy + EVibQ;
                label iMaxQ = (EcQ /(physicoChemical::k.value()*thetaVQ));

                if(iMaxQ > SMALL)
                {
                    // - Bird equations 5.42 and 11.34 gave this denominator
                    scalar TCollQ = (iMaxQ*thetaVQ) / (3.5 - omegaPQ); 
                    
                    scalar pow1 = pow((thetaDQ/TCollQ),0.333) - 1.0;

                    scalar pow2 = pow ((thetaDQ/refTempZvQ),0.333) -1.0;
                    
                    // - vibrational collision number (equation 2, Bird 2010)
                    scalar ZvQ1 = pow((thetaDQ/TCollQ),omegaPQ); 
                    
                    scalar ZvQ2 = pow(ZrefQ*(pow((thetaDQ/refTempZvQ),(-1.0*omegaPQ))),(pow1/pow2));
                    
                    scalar ZvQ = ZvQ1*ZvQ2;
        //             scalar ZvQ = 50.0;
                        
                    scalar inverseVibrationalCollisionNumberQ = 1.0/ZvQ;
                
                    if(inverseVibrationalCollisionNumberQ > cloud_.rndGen().scalar01())
                    {
                        label iDashQ = 0; // post-collision quantum number
                        scalar func = 0.0;

                        do // acceptance - rejection 
                        {
                            iDashQ = cloud_.rndGen().integer(0,iMaxQ);
                            EVibQ = iDashQ*physicoChemical::k.value()*thetaVQ;
                            func = pow((1.0 - (EVibQ / EcQ)),(1.5 - omegaPQ));
                    
                        } while( !(func > cloud_.rndGen().scalar01()) );
                
                        translationalEnergy = EcQ - EVibQ;
                    }
                }
                
                if (0.2 > cloud_.rndGen().scalar01())
                {
                    scalar EcQ = translationalEnergy + ERotQ;
                    
                    scalar energyRatio = 0.0;
                    
                    if(rotationalDofQ == 2.0)
                    {
                        energyRatio = 1.0 - pow(cloud_.rndGen().scalar01(),(1.0/ChiB));
                    }
                    else
                    {
                        scalar ChiA = 0.5*rotationalDofQ;
                        
                        energyRatio = cloud_.energyRatio(ChiA, ChiB);
                    }

                    ERotQ = energyRatio*EcQ;
                
                    translationalEnergy = EcQ - ERotQ;
                }
                
                scalar relVelNonDissoMol = sqrt((2.0*translationalEnergy)/mR);

                // centre of mass velocity of molecules (pre-split)
                vector Ucm = (mP*UP + mQ*UQ)/(mP + mQ);

                // Variable Hard Sphere collision part for collision of molecules
                scalar cosTheta = 2.0*cloud_.rndGen().scalar01() - 1.0;
            
                scalar sinTheta = sqrt(1.0 - cosTheta*cosTheta);
            
                scalar phi = twoPi*cloud_.rndGen().scalar01();
            
                vector postCollisionRelU =
                    relVelNonDissoMol
                    *vector
                        (
                            cosTheta,
                            sinTheta*cos(phi),
                            sinTheta*sin(phi)
                        );
        
                UP = Ucm + (postCollisionRelU*mQ/(mP + mQ)); // UP is used as Ucm for atomic split.
                UQ = Ucm - (postCollisionRelU*mP/(mP + mQ)); // Q is the NON-DISSOCIATING molecule.

                // Q remains NON-DISSOCIATED (but internal and translational energy modified).
//                 q.EVib() = Evib2;
//                 q.ERot() = Erot2;
                q.EVib() = EVibQ;
                q.ERot() = ERotQ;
                q.U() = UQ;

                //split particle P into the atoms
                const label& typeId1 = productIds_[0];
                const label& typeId2 = productIds_[1];

                //Mass of Product one and two
                scalar mP1 = cloud_.constProps(typeId1).mass();
                scalar mP2 = cloud_.constProps(typeId2).mass();

                scalar mRatoms = mP1*mP2/(mP1 + mP2);

                //centre of mass velocity
                vector UcmAtoms = UP;
                
                //the relative translational energy for the atoms
                //comes from the internal energy of the complex molecule
//                 scalar cRatoms = sqrt(2.0*Ecplx/mRatoms);
                
                scalar cRatoms = sqrt(2.0*ERotP/mRatoms);

                // Variable Hard Sphere collision part for atoms
                cosTheta = 2.0*cloud_.rndGen().scalar01() - 1.0;
            
                sinTheta = sqrt(1.0 - cosTheta*cosTheta);
            
                phi = twoPi*cloud_.rndGen().scalar01();
            
                vector postCollisionRelU2 = cRatoms
                *vector
                    (
                        cosTheta,
                        sinTheta*cos(phi),
                        sinTheta*sin(phi)
                    );

                vector uP1 = UcmAtoms + (postCollisionRelU2*mP2/(mP1 + mP2));
                vector uP2 = UcmAtoms - (postCollisionRelU2*mP1/(mP1 + mP2));

                // Molecule P will dissociate into 2 atoms.
                label cellI = p.cell();
                vector position = p.position();
                label tetFaceI = p.tetFace();
                label tetPtI = p.tetPt();
                    
                //convert the molecule to an atom
                p.typeId() = typeId1;
                p.U() = uP1;
                p.EVib() = 0.0;
                p.ERot() = 0.0;
                
                label classificationP = p.classification();

                // insert the second atom
                cloud_.addNewParcel
                (
                    position,
                    uP2,
                    0.0,
                    0.0,
                    cellI,
                    tetFaceI,
                    tetPtI,
                    typeId2,
                    0,
                    classificationP
                );
            }
        }
        else
        {
            relax_ = true;
        }
    }
}

void  dissociationTypeISameSpecies::outputResults(const label& counterIndex)
{
    if(writeRatesToTerminal_ == true)
    {
        // measure density 
//         if(counterIndex == 1)
//         {
            const List< DynamicList<dsmcParcel*> >& cellOccupancy
                = cloud_.cellOccupancy();
                
            volume_ = 0.0;

            label molsReactants = 0;

            forAll(cellOccupancy, c)
            {
                const List<dsmcParcel*>& parcelsInCell = cellOccupancy[c];

                forAll(parcelsInCell, pIC)
                {
                    dsmcParcel* p = parcelsInCell[pIC];

                    if(findIndex(reactantIds_, p->typeId()) != -1)
                    {
                        molsReactants++;
                    }
                }

               volume_ += mesh_.cellVolumes()[c];
            }
            
            scalar volume = volume_;
            label nTotReactions = nTotReactions_;

            //- Parallel communication
            if(Pstream::parRun())
            {
                reduce(molsReactants, sumOp<label>());
                reduce(volume, sumOp<scalar>());
                reduce(nTotReactions, sumOp<label>());
            }

            numberDensities_[0] = (molsReactants*cloud().nParticle())/volume;
            numberDensities_[1] = (molsReactants*cloud().nParticle())/volume;
//         }   

        const scalar& deltaT = mesh_.time().deltaT().value();

        word reactantMolA = cloud_.typeIdList()[reactantIds_[0]];
        word reactantMolB = cloud_.typeIdList()[reactantIds_[1]];

        word productMolA = cloud_.typeIdList()[productIds_[0]];
        word productMolB = cloud_.typeIdList()[productIds_[1]];

        if((numberDensities_[0] > 0.0) && (numberDensities_[1] > 0.0))
        {
            scalar reactionRate = 0.0;
            
            reactionRate =
            (
                nTotReactions
                * cloud_.nParticle()
            )/(counterIndex*deltaT*numberDensities_[0]* numberDensities_[1]*volume);
               
            Info<< "Dissociation type I reaction " 
                <<  reactantMolA << " + " << reactantMolB
                <<  " --> " 
                << productMolA << " + " << productMolB << " + " << reactantMolB 
                << ", reaction rate = " << reactionRate
                << endl;
        }
    }
    else
    {
        label nTotReactions = nTotReactions_;   
        
        if(Pstream::parRun())
        {
            reduce(nTotReactions, sumOp<label>());
        }
       
       if(nTotReactions > VSMALL)
       {
            word reactantMolA = cloud_.typeIdList()[reactantIds_[0]];
            word reactantMolB = cloud_.typeIdList()[reactantIds_[1]];

            word productMolA = cloud_.typeIdList()[productIds_[0]];
            word productMolB = cloud_.typeIdList()[productIds_[1]];
           
            Info<< "Dissociation type I reaction " 
                <<  reactantMolA << " + " << reactantMolB
                <<  " --> " 
                << productMolA << " + " << productMolB << " + " << reactantMolB 
                << " is active." << endl;
       }       
    }

    nReactionsPerTimeStep_ = 0.0;

}


const bool& dissociationTypeISameSpecies::relax() const
{
    return relax_;
}

}
// End namespace Foam

// ************************************************************************* //
